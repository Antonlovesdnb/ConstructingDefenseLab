Splunk Add-on for Microsoft Windows
Copyright (C) 2021 Splunk Inc. All Rights Reserved.

For documentation, see: http://docs.splunk.com/Documentation/WindowsAddOn/latest
