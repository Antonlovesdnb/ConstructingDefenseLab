Put files needed for the role here.
Avoid putting large files (i.e. ISOs) here, instead download them.
Avoid any proprietary software/files you are not authorized to distribute (i.e. Microsoft software), instead download them.